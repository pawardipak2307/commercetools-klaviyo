export const ctGet2Categories = {
	"limit": 20,
  "offset": 0,
  "count": 2,
  "results": [
    {
        "id": "84595235-0e65-4c0c-b44c-9566aeea8017",
        "version": 1,
        "versionModifiedAt": "2023-01-19T13:39:11.678Z",
        "lastMessageSequenceNumber": 1,
        "createdAt": "2023-01-19T13:39:11.678Z",
        "lastModifiedAt": "2023-01-19T13:39:11.678Z",
        "lastModifiedBy": {
            "clientId": "GoA0a0o2TXhrpN2TPDOBa9Rr",
            "isPlatformClient": false
        },
        "createdBy": {
            "clientId": "GoA0a0o2TXhrpN2TPDOBa9Rr",
            "isPlatformClient": false
        },
        "key": "c2",
        "name": {
            "de": "Frauen",
            "en": "Women",
            "it": "Donna"
        },
        "slug": {
            "de": "women",
            "en": "women",
            "it": "women"
        },
        "ancestors": [],
        "orderHint": "0.0002",
        "externalId": "2",
        "assets": []
    },
    {
        "id": "74c1627f-d004-4278-bc61-29a43fba907d",
        "version": 1,
        "versionModifiedAt": "2023-01-19T13:39:11.822Z",
        "lastMessageSequenceNumber": 1,
        "createdAt": "2023-01-19T13:39:11.822Z",
        "lastModifiedAt": "2023-01-19T13:39:11.822Z",
        "lastModifiedBy": {
            "clientId": "GoA0a0o2TXhrpN2TPDOBa9Rr",
            "isPlatformClient": false
        },
        "createdBy": {
            "clientId": "GoA0a0o2TXhrpN2TPDOBa9Rr",
            "isPlatformClient": false
        },
        "key": "c1",
        "name": {
            "de": "Neu",
            "en": "New",
            "it": "New"
        },
        "slug": {
            "de": "new",
            "en": "new",
            "it": "new"
        },
        "ancestors": [],
        "orderHint": "0.0001",
        "externalId": "1",
        "assets": []
    }
  ]
}
