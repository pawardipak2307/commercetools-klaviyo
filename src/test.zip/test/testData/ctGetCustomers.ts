export const ctGet2Customers = {
	"limit": 20,
  "offset": 0,
  "count": 2,
  "results": [
    {
      "id": "33c11557-af1c-4104-a1fb-8de2434ded66",
      "version": 1,
      "versionModifiedAt": "2023-02-15T09:52:49.682Z",
      "lastMessageSequenceNumber": 1,
      "createdAt": "2023-02-15T09:52:49.682Z",
      "lastModifiedAt": "2023-02-15T09:52:49.682Z",
      "lastModifiedBy": {
        "clientId": "3bdbmCvX60kN6G-HfzLxcmlB",
        "isPlatformClient": false
      },
      "createdBy": {
        "clientId": "3bdbmCvX60kN6G-HfzLxcmlB",
        "isPlatformClient": false
      },
      "email": "Maximilian.Volkman@hotmail.com",
      "firstName": "Kaylee",
      "lastName": "Bayer",
      "title": "Miss",
      "password": "****v3U=",
      "addresses": [
        {
          "id": "7eWCzkiN",
          "title": "Mrs.",
          "firstName": "Caleigh",
          "lastName": "Parisian",
          "streetName": "First Street",
          "streetNumber": "12",
          "postalCode": "12345",
          "city": "Raleigh",
          "country": "NL",
          "phone": "+39 3234567892",
          "mobile": "+39 3234567892",
          "email": "jane.doe@example.com"
        },
        {
          "id": "X8FX1OcS",
          "title": "Head of factory",
          "firstName": "Jane",
          "lastName": "Doe",
          "streetName": "Third Street",
          "streetNumber": "34",
          "postalCode": "12345",
          "city": "Example City",
          "country": "NL",
          "phone": "+3112345678",
          "mobile": "+3112345679",
          "email": "jane.doe@example.com"
        }
      ],
      "shippingAddressIds": [],
      "billingAddressIds": [],
      "isEmailVerified": false,
      "stores": [],
      "authenticationMode": "Password"
    },
    {
      "id": "813546ce-40b3-440b-8c04-489bc530d162",
      "version": 1,
      "versionModifiedAt": "2023-02-21T12:11:53.441Z",
      "lastMessageSequenceNumber": 1,
      "createdAt": "2023-02-21T12:11:53.441Z",
      "lastModifiedAt": "2023-02-21T12:11:53.441Z",
      "lastModifiedBy": {
        "clientId": "3bdbmCvX60kN6G-HfzLxcmlB",
        "isPlatformClient": false
      },
      "createdBy": {
        "clientId": "3bdbmCvX60kN6G-HfzLxcmlB",
        "isPlatformClient": false
      },
      "email": "Brisa_Schowalter@yahoo.com",
      "firstName": "Yvette",
      "lastName": "Collins",
      "title": "Miss",
      "password": "****Cxk=",
      "addresses": [
        {
          "id": "hmzrqUsV",
          "title": "Mrs.",
          "firstName": "Claud",
          "lastName": "Hyatt",
          "streetName": "First Street",
          "streetNumber": "12",
          "postalCode": "12345",
          "city": "East Bertrandmouth",
          "country": "NL",
          "phone": "+39 3234567892",
          "mobile": "+39 3234567892",
          "email": "jane.doe@example.com"
        },
        {
          "id": "UzUX-FdH",
          "title": "Head of factory",
          "firstName": "Jane",
          "lastName": "Doe",
          "streetName": "Third Street",
          "streetNumber": "34",
          "postalCode": "12345",
          "city": "Example City",
          "country": "NL",
          "phone": "+3112345678",
          "mobile": "+3112345679",
          "email": "jane.doe@example.com"
        }
      ],
      "shippingAddressIds": [],
      "billingAddressIds": [],
      "isEmailVerified": false,
      "stores": [],
      "authenticationMode": "Password"
    },
  ]
}
