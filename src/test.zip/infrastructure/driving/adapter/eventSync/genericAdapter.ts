export type GenericAdapter = () => Promise<any>;
